// hashtable.hpp
// A C++ hash table class
// Mike Johanson, October 30, 2014

#include "linkedlist.hpp"

class HashTable {
public:
  HashTable( unsigned int newSize );
  ~HashTable();

  void add( const char *str );
  int check( const char *str );
  
  unsigned int getNumEntries();
  void getStats( unsigned int *shortestListLength,
		 unsigned int *longestListLength );

private:
  unsigned int tableSize;
  SList *table;
};
