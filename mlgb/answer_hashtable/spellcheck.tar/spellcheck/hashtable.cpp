// hashtable.cpp
// A C++ hash table class
// Mike Johanson, October 30, 2014

#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "hashtable.hpp"
#include "util.hpp"

HashTable::HashTable( unsigned int newSize )
{
  tableSize = newSize;
  table = new SList[ tableSize ];
}

HashTable::~HashTable()
{
  delete [] table;
}

void HashTable::add( const char *str )
{
  unsigned int hash = hashString( str, tableSize );
  table[ hash ].add_unique( str );
}

int HashTable::check( const char *str )
{
  unsigned int hash = hashString( str, tableSize );
  Node *n = table[ hash ].find( str );
  return (n != NULL);
}

unsigned int HashTable::getNumEntries()
{
  unsigned int total = 0;
  for( unsigned int i = 0; i < tableSize; i++ ) {
    total += (unsigned int) table[ i ].size();
  }
  return total;
}

void HashTable::getStats( unsigned int *shortestListLength,
			  unsigned int *longestListLength )
{
  unsigned int n = (unsigned int) table[0].size();
  *shortestListLength = n;
  *longestListLength = n;
  unsigned int i;
  for( i = 1; i < tableSize; i++ ) {
    n = (unsigned int) table[ i ].size();
    if( n < *shortestListLength ) {
      *shortestListLength = n;
    }
    if( n > *longestListLength ) {
      *longestListLength = n;
    }
  }
}
