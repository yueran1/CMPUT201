// spellcheck.cpp
// A simple spell-checking program,
// powered by a hash table.
// Mike Johanson, October 30, 2014

#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <sys/time.h>

#include "hashtable.hpp"
#include "util.hpp"
#include "linkedlist.hpp"

// 'words' is a dictionary file: one word on each line.
// .  It's at this path on Mac OSX and
// the lab computers.  If compiling and running this program elsewhere,
// make sure this file exists.
//
// For testing, try making a replacement file in your own filespace,
// fill it with 4-5 words (one per line), and change
// dictionaryPath to the name of your replacement file.
const char *dictionaryPath = "/usr/share/dict/words";


int main( const int argc, const char *argv[] )
{
  if( argc != 2 ) {
    printf( "Usage: ./spellcheck <file>\n" );
    return 1;
  }

  // Create hash table, fill it with dictionary
  // Parameter is the number of entries in the hash table.
  // Any number > 0 will do.  Bigger is faster, and uses
  // a tiny amount more memory, but this is very small
  // compared to memory needed to store the dictionary.
  // For debugging, you may want to use a smaller number.
  //
  // To get an even distribution of words across the entries in
  // the hash table, we want the number of entries (29989 here)
  // and the hashing constant (31, in util.cpp) to be
  // relatively prime.
  unsigned int tableSize = 29989;
  HashTable ht( tableSize );

  printf("Loading dictionary file [%s]...\n", dictionaryPath );
  struct timeval dictStart;
  gettimeofday( &dictStart, NULL );

  // Open the dictionary file, add words
  FILE *stream = fopen( dictionaryPath, "r" );
  if( stream == NULL ) {
    printf( "Couldn't open dictionary file [%s]\n", dictionaryPath );
    return 1;
  }

  // Add words
  char buffer[ 1000 ];
  char copy[ 1000 ];
  while( fgets( buffer, 1000, stream ) != NULL ) {
    // process the string - convert to lowercase, remove
    // punctuation.
    processString( buffer );
    ht.add( buffer );
  }
  
  // Close dictionary
  fclose( stream );

  struct timeval dictEnd;
  gettimeofday( &dictEnd, NULL );
  double dictLoadTime = (double)(dictEnd.tv_sec - dictStart.tv_sec) + (double)(dictEnd.tv_usec - dictStart.tv_usec) / 1000000.0;

  unsigned int numEntries = ht.getNumEntries();
  printf("Dictionary loaded (%u words).  Load took %lf seconds.\n", numEntries, dictLoadTime );

  unsigned int shortest, longest;
  ht.getStats( &shortest, &longest );
  printf("Shortest list length: %u.  Longest list length: %u\n", shortest, longest );
  printf("%u lists; average of %lf words / list\n", tableSize, (numEntries * 1.0) / ( tableSize * 1.0 ) );

  printf("\nSpellchecking file [%s]\n", argv[ 1 ] );

  struct timeval spellStart;
  gettimeofday( &spellStart, NULL );

  unsigned int numWords = 0;
  unsigned int numTypos = 0;
  // Open input file, check contents
  stream = fopen( argv[ 1 ], "r" );
  while( fscanf( stream, "%1000s", buffer ) != EOF ) {
    strncpy( copy, buffer, 1000 );
    processString( buffer );
    // After processing, is the word non-empty?
    if( buffer[ 0 ] != '\0') {
      numWords++;
      if( ht.check( buffer ) == 0 ) {
	// Word was not found in the hash table!
	printf("  [%s], originally [%s]\n", buffer, copy );
	numTypos++;
      }
    }
  }
  fclose( stream );
  
  struct timeval spellEnd;
  gettimeofday( &spellEnd, NULL );
  double spellTime = (double)(spellEnd.tv_sec - spellStart.tv_sec) + (double)(spellEnd.tv_usec - spellStart.tv_usec) / 1000000.0;
  
  printf("Spellcheck complete: %u words and %u errors.  Took %lf seconds\n", numWords, numTypos, spellTime );

  return 0;
}
