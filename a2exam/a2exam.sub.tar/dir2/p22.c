#include<string>
#include<iostream>
using namesapce std;

int main()
{
  string s;
  s='a'+'14';
  cout << s<<endl;

}
