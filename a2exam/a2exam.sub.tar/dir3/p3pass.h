#pragma once

bool check(unsigned long guess);
